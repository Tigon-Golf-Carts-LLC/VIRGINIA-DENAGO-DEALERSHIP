# DENAGO ROVER XXL

- **Brand:** DENAGO (`denago`)
- **Model slug:** `ev-rover-xxl`
- **URL:** `/denago/ev-rover-xxl`
- **Series:** ROVER XXL
- **Category:** Family / Commercial
- **Tagline:** Maximum capacity. Ultimate luxury.

## Description
The DENAGO ROVER XXL accommodates up to 8 passengers with an ultra-premium interior, advanced technology suite, and industry-leading range. The ultimate in electric vehicle luxury for large families and commercial applications.

## Key Specs
- **Price (MSRP):** $12,995
- **Seats:** 8
- **Range:** 60 miles
- **Top Speed:** 25 mph
- **Drive Type:** 2x4

## Features
- 8-Passenger Maximum Capacity
- Ultra-Premium Interior
- Advanced Technology Suite
- Superior Performance
- Extended Range Battery
- Premium Entertainment
- Luxury Seating
- State-of-the-Art Features

## Full Specifications
| Spec | Value |
| --- | --- |
| Top Speed | 25 mph |
| Range | 60 miles |
| Seating | 8 Passengers |
| Motor | High-Performance AC Motor |
| Battery | Extended Lithium Ion |
| Charging | 10–12 hours |
| Drive | 2x4 |
| Interior | Ultra-Premium |
| Payload | 1,600 lbs |
| Technology | Advanced Suite |

## Images
- `images/denago-ev-rover-xxl.jpg`

## Source image reference
- Primary `image` field: `/assets/denago/denago-ev-rover-xxl.jpg`

## External (manufacturer) URL
https://tigongolfcarts.com/denago-ev/rover-xxl/
