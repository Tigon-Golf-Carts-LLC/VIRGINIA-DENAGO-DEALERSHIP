# DENAGO — Brand Mapping

- **Slug / URL base:** `/denago`
- **Model URL pattern:** `/denago/{model-slug}`
- **Models:** 6
- **Data source:** `client/src/data/denago-models.ts`
- **Landing page:** `client/src/pages/brands/denago.tsx`
- **Model page:** `client/src/pages/brands/denago-model.tsx`
- **Page type:** Featured brand — custom hand-built landing page


## Folder layout
- `source/` — verbatim copies of this brand's landing page, model page, and data file.
- `{model-slug}/` — one folder per model:
  - `info.md` — human-readable model spec sheet.
  - `info.json` — the raw `VehicleModel` record (source of truth).
  - `images/` — the model's image(s), including color variants where defined.

## Models
- **CITY** — `/denago/ev-city` — 2 seats, 25 mph, $16,500
- **NOMAD** — `/denago/ev-nomad` — 4 seats, 25 mph, $9,995
- **NOMAD XL** — `/denago/ev-nomad-xl` — 4 seats, 25 mph, $9,995
- **ROVER XL** — `/denago/ev-rover-xl` — 6 seats, 25 mph, $10,995
- **ROVER XL6** — `/denago/ev-rover-xl6` — 6 seats, 25 mph, $12,995
- **ROVER XXL** — `/denago/ev-rover-xxl` — 8 seats, 25 mph, $12,995

## Layout & build
See `../README.md` for the shared page anatomy, routing, nav-menu wiring, and how to rebuild a brand page.
