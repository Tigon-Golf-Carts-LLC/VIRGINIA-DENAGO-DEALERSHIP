# DENAGO CITY

- **Brand:** DENAGO (`denago`)
- **Model slug:** `ev-city`
- **URL:** `/denago/ev-city`
- **Series:** CITY
- **Category:** Street Legal / NEV
- **Tagline:** Urban mobility redefined.

## Description
The DENAGO CITY is a street-legal Neighborhood Electric Vehicle built for city transportation, campuses, and neighborhood use. Featuring a sleek design, efficient battery system, and all required DOT safety equipment, it's the ideal urban companion.

## Key Specs
- **Price (MSRP):** $16,500
- **Seats:** 2
- **Range:** 40–50 miles
- **Top Speed:** 25 mph
- **Drive Type:** 2x4

## Features
- Street Legal NEV Certified
- LED Lighting Package
- Premium Interior Design
- Urban Mobility Optimized
- Efficient Battery System
- Sleek Modern Styling
- Digital Display
- DOT-Approved Safety Equipment

## Full Specifications
| Spec | Value |
| --- | --- |
| Top Speed | 25 mph |
| Range | 40–50 miles |
| Seating | 2 Passengers |
| Motor | AC Electric Motor |
| Battery | Lithium Ion |
| Charging | 6–8 hours (110V) |
| Length | 142 inches |
| Width | 58 inches |
| Height | 74 inches |
| Payload | 900 lbs |

## Images
- `images/denago-ev-city.jpg`

## Source image reference
- Primary `image` field: `/assets/denago/denago-ev-city.jpg`

## External (manufacturer) URL
https://tigongolfcarts.com/denago-ev/city/
