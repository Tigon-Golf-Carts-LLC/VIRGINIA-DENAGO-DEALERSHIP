# DENAGO NOMAD XL

- **Brand:** DENAGO (`denago`)
- **Model slug:** `ev-nomad-xl`
- **URL:** `/denago/ev-nomad-xl`
- **Series:** NOMAD XL
- **Category:** Off-Road / Adventure
- **Tagline:** Extended range. Elevated adventure.

## Description
The DENAGO NOMAD XL takes the Nomad platform further with an extended range battery, premium off-road package, and enhanced cargo capacity. Built for serious adventurers who need more from their electric vehicle.

## Key Specs
- **Price (MSRP):** $9,995
- **Seats:** 4
- **Range:** 55 miles
- **Top Speed:** 25 mph
- **Drive Type:** 2x4

## Features
- Extended Range Battery
- Premium Off-Road Package
- Enhanced Cargo Space
- All-Weather Protection
- Superior Suspension
- Heavy-Duty Construction
- Advanced Battery Management
- Premium Interior

## Full Specifications
| Spec | Value |
| --- | --- |
| Top Speed | 25 mph |
| Range | 55 miles |
| Seating | 4 Passengers |
| Motor | AC Electric Motor |
| Battery | Extended Lithium Ion |
| Charging | 6–8 hours |
| Drive | 2x4 |
| Cargo | Enhanced Capacity |
| Suspension | Heavy-Duty Lifted |
| Payload | 1,100 lbs |

## Images
- `images/denago-ev-nomad-xl.jpg`

## Source image reference
- Primary `image` field: `/assets/denago/denago-ev-nomad-xl.jpg`

## External (manufacturer) URL
https://tigongolfcarts.com/denago-ev/nomad-xl/
