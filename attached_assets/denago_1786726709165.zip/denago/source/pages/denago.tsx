import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Phone, Zap, ChevronRight, ExternalLink, Users, Gauge, Battery } from "lucide-react";
import { PHONE_NUMBER, PHONE_TEL } from "@/lib/constants";
import { denagoModels } from "@/data/denago-models";
import { BackToSearch } from "@/components/back-to-search";
import { Breadcrumbs } from "@/components/breadcrumbs";
import { buildBrandTrail } from "@shared/breadcrumbs";
import { BrandInventoryCarousel } from "@/components/brand-inventory-carousel";

const BRAND_COLOR = "#1a2e6b";
const ACCENT_COLOR = "#2563eb";
const APPLY_URL = "/financing";

export default function DenagoPage() {
  return (
    <div className="min-h-screen bg-background">
      {/* Breadcrumb */}
      <Breadcrumbs
        items={buildBrandTrail("DENAGO")}
        className="border-b bg-muted/30"
        containerClassName="max-w-7xl mx-auto px-4 py-3"
      />

      <BackToSearch />

      {/* Hero */}
      <section
        className="py-16 px-4 text-white"
        style={{ background: `linear-gradient(135deg, ${BRAND_COLOR} 0%, #0f1f4a 100%)` }}
        data-testid="section-brand-hero"
      >
        <div className="max-w-7xl mx-auto text-center">
          <Badge className="mb-6 bg-white/20 text-white border-white/30 text-sm px-4 py-1.5">
            Premium Electric Vehicles
          </Badge>
          <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold tracking-tight mb-4" data-testid="text-brand-name">
            DENAGO<span className="text-blue-300">®</span>
          </h1>
          <p className="text-xl text-white/80 max-w-2xl mx-auto mb-8 leading-relaxed" data-testid="text-brand-tagline">
            Street-legal electric vehicles engineered for adventure, family, and modern urban living.
            Discover the full DENAGO EV lineup available at TIGON Golf Carts.
          </p>
          <div className="flex flex-wrap justify-center gap-4">
            <a href={PHONE_TEL} data-testid="button-hero-call">
              <Button size="lg" className="bg-white text-gray-900 hover:bg-gray-100 font-bold">
                <Phone className="h-4 w-4 mr-2" />
                Call Now — {PHONE_NUMBER}
              </Button>
            </a>
            <a href={APPLY_URL} target="_blank" rel="noopener noreferrer" data-testid="button-hero-apply">
              <Button size="lg" variant="outline" className="border-white text-white hover:bg-white/10">
                Apply Now — 0% Financing
              </Button>
            </a>
          </div>
        </div>
      </section>

      {/* Brand Highlights */}
      <section className="py-10 px-4 border-b bg-muted/20">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 text-center">
            {[
              { icon: Zap, label: "All Electric", desc: "Zero emissions lineup" },
              { icon: Battery, label: "Lithium Powered", desc: "Advanced battery tech" },
              { icon: Users, label: "2–8 Passengers", desc: "Every family size" },
              { icon: Gauge, label: "NEV Certified", desc: "Street legal options" },
            ].map((item) => (
              <div key={item.label} className="flex flex-col items-center gap-2">
                <div className="w-10 h-10 rounded-full flex items-center justify-center" style={{ backgroundColor: `${BRAND_COLOR}15` }}>
                  <item.icon className="h-5 w-5" style={{ color: BRAND_COLOR }} />
                </div>
                <div className="text-sm font-semibold">{item.label}</div>
                <div className="text-xs text-muted-foreground">{item.desc}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Model Grid */}
      <section className="py-14 px-4" data-testid="section-models">
        <div className="max-w-7xl mx-auto">
          <div className="mb-10 text-center">
            <h2 className="text-3xl font-bold mb-2">DENAGO EV Models</h2>
            <p className="text-muted-foreground">Select a model to view full specifications and details</p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {denagoModels.map((model) => (
              <Link key={model.slug} href={`/denago/${model.slug}`}>
                <div
                  className="group rounded-xl border bg-card overflow-hidden hover:shadow-lg transition-all cursor-pointer hover:-translate-y-0.5"
                  data-testid={`card-model-${model.slug}`}
                >
                  <div className="aspect-[4/5] bg-muted relative overflow-hidden">
                    <img
                      src={model.image}
                      alt={model.name}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                    />
                    <div className="absolute top-3 left-3">
                      <Badge className="text-xs text-white" style={{ backgroundColor: BRAND_COLOR }}>
                        {model.category}
                      </Badge>
                    </div>
                  </div>
                  <div className="p-5">
                    <h3 className="font-bold text-lg mb-1" data-testid={`text-model-name-${model.slug}`}>{model.series}</h3>
                    <p className="text-sm text-muted-foreground mb-4 line-clamp-2">{model.tagline}</p>
                    <div className="grid grid-cols-3 gap-2 mb-4">
                      <div className="text-center rounded-md bg-muted/50 py-2 px-1">
                        <div className="text-xs text-muted-foreground">Seats</div>
                        <div className="text-sm font-bold">{model.seats}</div>
                      </div>
                      <div className="text-center rounded-md bg-muted/50 py-2 px-1">
                        <div className="text-xs text-muted-foreground">Range</div>
                        <div className="text-sm font-bold leading-tight">{model.range}</div>
                      </div>
                      <div className="text-center rounded-md bg-muted/50 py-2 px-1">
                        <div className="text-xs text-muted-foreground">Speed</div>
                        <div className="text-sm font-bold">{model.topSpeed}</div>
                      </div>
                    </div>
                    {(() => {
                      const num = parseFloat(model.price.replace(/[$,]/g, ""));
                      return !isNaN(num) ? (
                        <div className="mb-3 rounded-lg border bg-muted/30 px-3 py-2 flex items-center justify-between">
                          <div>
                            <p className="text-[10px] text-muted-foreground uppercase tracking-wide font-medium">MSRP</p>
                            <p className="text-base font-extrabold" style={{ color: BRAND_COLOR }}>${num.toLocaleString("en-US")}</p>
                          </div>
                          <div className="text-right">
                            <p className="text-[10px] text-muted-foreground uppercase tracking-wide font-medium">0% / 36 mo</p>
                            <p className="text-sm font-bold">${Math.ceil(num / 36).toLocaleString("en-US")}<span className="text-xs font-normal text-muted-foreground">/mo</span></p>
                          </div>
                        </div>
                      ) : (
                        <p className="text-xs text-muted-foreground mb-3">{model.price}</p>
                      );
                    })()}
                    <Button size="sm" style={{ backgroundColor: BRAND_COLOR }} className="w-full text-white hover:opacity-90 text-xs gap-1">
                      View Details <ChevronRight className="h-3 w-3" />
                    </Button>
                  </div>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>

      <BrandInventoryCarousel brandSlug="denago" displayName="DENAGO" brandColor={BRAND_COLOR} />

      {/* CTA */}
      <section className="py-14 px-4 text-white" style={{ background: `linear-gradient(135deg, ${BRAND_COLOR} 0%, ${ACCENT_COLOR} 100%)` }}>
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-3xl font-bold mb-3">Ready to Go Electric with DENAGO?</h2>
          <p className="text-white/80 mb-8 text-lg">
            Call TIGON Golf Carts now to check availability, pricing, and qualify for 0% financing.
          </p>
          <div className="flex flex-wrap gap-4 justify-center">
            <a href={PHONE_TEL} data-testid="button-cta-call">
              <Button size="lg" className="bg-white hover:bg-gray-100 text-gray-900 font-bold">
                <Phone className="h-5 w-5 mr-2" />
                Call Now — {PHONE_NUMBER}
              </Button>
            </a>
            <a href={APPLY_URL} target="_blank" rel="noopener noreferrer" data-testid="button-cta-apply">
              <Button size="lg" variant="outline" className="border-white text-white hover:bg-white/10">
                Apply Now — 0% Financing
              </Button>
            </a>
          </div>
        </div>
      </section>
    </div>
  );
}
