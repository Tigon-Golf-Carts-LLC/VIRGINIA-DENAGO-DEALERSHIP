import { useParams } from "wouter";
import { denagoModels } from "@/data/denago-models";
import StaticVehiclePage from "@/components/static-vehicle-page";
import NotFound from "@/pages/not-found";

const BRAND_COLOR = "#1a2e6b";
const ACCENT_COLOR = "#2563eb";

export default function DenagoModelPage() {
  const { model: slug } = useParams<{ model: string }>();
  const model = denagoModels.find((m) => m.slug === slug);

  if (!model) return <NotFound />;

  return (
    <StaticVehiclePage
      model={model}
      brand="DENAGO"
      brandSlug="denago"
      brandColor={BRAND_COLOR}
      accentColor={ACCENT_COLOR}
    />
  );
}
