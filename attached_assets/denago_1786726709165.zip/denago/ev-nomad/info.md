# DENAGO NOMAD

- **Brand:** DENAGO (`denago`)
- **Model slug:** `ev-nomad`
- **URL:** `/denago/ev-nomad`
- **Series:** NOMAD
- **Category:** Off-Road / Adventure
- **Tagline:** Adventure-ready for any terrain.

## Description
The DENAGO NOMAD is built for exploration. With all-terrain tires, lifted suspension, and enhanced ground clearance, this electric vehicle combines rugged durability with clean electric efficiency — perfect for off-road adventures.

## Key Specs
- **Price (MSRP):** $9,995
- **Seats:** 4
- **Range:** 45 miles
- **Top Speed:** 25 mph
- **Drive Type:** 2x4

## Features
- All-Terrain Tires
- Lifted Suspension
- Adventure Package
- Enhanced Ground Clearance
- Rugged Construction
- Off-Road Capabilities
- Durable Frame
- Weather Protection

## Full Specifications
| Spec | Value |
| --- | --- |
| Top Speed | 25 mph |
| Range | 45 miles |
| Seating | 4 Passengers |
| Motor | AC Electric Motor |
| Battery | Lithium Ion |
| Charging | 6–8 hours |
| Drive | 2x4 |
| Tires | All-Terrain |
| Suspension | Lifted |
| Payload | 1,000 lbs |

## Images
- `images/denago-ev-nomad.jpg`

## Source image reference
- Primary `image` field: `/assets/denago/denago-ev-nomad.jpg`

## External (manufacturer) URL
https://tigongolfcarts.com/denago-ev/nomad/
